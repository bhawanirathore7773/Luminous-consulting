from django.apps import AppConfig


class CaseStudiesConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "case_studies"
    label = "case_studies"
